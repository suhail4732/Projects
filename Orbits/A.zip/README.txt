"N-body 2D optimized code" and "N-body 3d optimize code" are my fastest code to plot N-body system.

Change the intial conditions Mass, 
position,velocity and time for the system. 

Change the tolerance if needed to make sure the relative energy change isn't too high.
Make sure the size for each of the intial condition parameters are the same otherwise the code wouldn't run


To get Figure (1) and Figure (2) run "2-body First code" and this will give you the result. You could change the intial conditions 
on the
"N-body 2D optimized code".

To get Figure (3) run "Barrah problems", you can change t1 and t2 for different results as shown in the paper 
for different time intervals.

To get Figure (4) run "Same orbit"

To get Figure(5) run "Solar system 2D subplots"


To get Figure(6) run "N-body 3d optimize 3D orbit"

To get Figure(7) run "N- body optimized 3D solar system"